import React from 'react'

const VoterReports = () => {
    return (
        <div>VoterReports</div>
    )
}

export default VoterReports